'use strict';

const arr = [1,4,6,3,8];

let acc= 0;

for (let i=0; i<arr.length; i++){
    acc += arr[i]}

console.log(`La suma es ${acc}`);

let average = acc/arr.length;

console.log(average);